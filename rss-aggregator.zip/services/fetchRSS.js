const Parser = require("rss-parser");
const parser = new Parser();

const feeds = [
  "https://www.prothomalo.com/feed/",
  "https://www.kalerkantho.com/rss.xml",
  "https://www.bbc.com/bengali/index.xml"
];

async function fetchRSS() {
  const allFeeds = [];

  for (const url of feeds) {
    try {
      const feed = await parser.parseURL(url);
      const items = feed.items.slice(0, 5).map(item => ({
        title: item.title,
        link: item.link,
        source: feed.title
      }));
      allFeeds.push(...items);
    } catch (err) {
      console.error("❌ Error fetching feed:", url);
    }
  }

  return allFeeds;
}

module.exports = fetchRSS;
